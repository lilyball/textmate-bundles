#!/usr/bin/env python

import os
import sys
import exctags
import cgi
import re
import template

replacement_string = '<!--REPLACE WITH BODY-->'

def hilight(text, pattern):
	res = []
	end = 0
	for i in re.finditer(pattern, text):
		res.append(text[end : i.start()])
		res.append('<span class="hilight">' + text[i.start() : i.end()] + '</span>')
		end = i.end()
	res.append(text[end : ])
	return ''.join(res)

def done(body):
	return template.html.replace(replacement_string, ''.join(body))

def lookup():
	''' Returns a tuple; first the html, and then the success indicator.'''
	
	body = []
	
	lookup = os.environ.get('TM_SELECTED_TEXT', os.environ.get('TM_CURRENT_WORD', None))

	if not lookup:
		# try the command line
		if len(sys.argv) > 1:
			lookup = sys.argv[1]

	if not lookup:
		body.append('<h1>No text to lookup</h1>')
		return done(body), -1

	tagfile = None
	if os.environ.has_key('TM_TAG_FILE'):
		tagfile = os.environ['TM_TAG_FILE']
	elif os.environ.has_key('TM_PROJECT_DIRECTORY'):
		tmp = os.path.join(os.environ['TM_PROJECT_DIRECTORY'], 'tags')
		if os.path.exists(tmp):
			tagfile = tmp

	# If a tag file wasn't found, Tags will search for one.
	try:
		ctags = exctags.Tags(tagfile = tagfile, 
				startdir = os.path.dirname(os.environ.get('TM_FILEPATH', 
						os.getcwd() + '/')))
	except RuntimeError, error:
		body.extend(['<h1>', str(error), '</h1>'])
		return done(body), -1
	
	body.extend(['<div class="smaller right">', str(ctags.tagfile), '</div>'])

	# Try an exact match first.
	lookup_type = 'exact match'
	matches = ctags.exact(lookup)
	if not matches:
		# Try partial if nothing was found
		lookup_type = 'partial match'
		matches = ctags.partial(lookup)
	
	body.extend(['<center><h3>', '%s &nbsp; &nbsp; &nbsp; %s' % (lookup, lookup_type), '</h3></center>'])
	if not matches:
		body.append('<h3>No matching tags found</h3>')
	else:
		body.append('<center class="smaller">')
		body.append('<a href="javascript:void(0)" onclick="showAll();">Show All</a>')
		body.append(' &nbsp;&nbsp;&nbsp; ')
		body.append('<a href="javascript:void(0)" onclick="hideAll();">Hide All</a>')
		body.append('</center>')
		body.append('<ul>')
		for i in matches:
			tagcode, tagline = ctags.code(i, buffer = 5)
			body.append('<li>')
			body.append('''
					<a class="show" href="javascript:void(0)" 
						onclick="var e = document.getElementById('%d');
						if (e.style.display == 'block') {
							e.style.display = 'none';
							this.innerHTML = 'show';
						} else {
							e.style.display = 'block';
							this.innerHTML = 'hide';
						}
						">show</a>
					''' % (matches.index(i)))
			f = os.path.abspath(os.path.join(os.path.dirname(ctags.tagfile), i['file']))
			tmp = cgi.escape('file://%s&line=%d' % (f, tagline))
			tagurl = 'txmt://open?url=%s' % tmp
			body.append('<a href=%s>%s:%d</a>' % (tagurl, i['file'], tagline))
			tagkind = exctags.tagKinds.get(i['kind'], i['kind'])
			body.append('<div class="smaller">kind - ')
			body.append(tagkind)
			body.append('</div>')
			body.append('<pre class="code" id="%d">' % matches.index(i))
			body.append(hilight(cgi.escape(tagcode), i['name']))
			body.append('</pre>')
			body.append('</li>')
		body.append('</ul>')
	return done(body), 0

if __name__ == '__main__':
	print lookup()[0]
