#!/usr/bin/env python

import os
import sys
import exctags
import cgi
import re
import template

replace_body = '<!--REPLACE WITH BODY-->'


def hilight(text, pattern):
	res = []
	end = 0
	for i in re.finditer(pattern, text):
		res.append(text[end : i.start()])
		res.append('<span class="hilight">' + text[i.start() : i.end()] + '</span>')
		end = i.end()
	res.append(text[end : ])
	return ''.join(res)

def done(body):
	return template.html.replace(replace_body, ''.join(body))

def lookup(name, tagfile = None, startdir = None):
	''' 
		Returns a tuple; first the html, and then the success indicator. If
        tagpath is a file, that will be the tags file used. If tagpath is a
        directory, the directory will be used as the starting search dir. If
        tagpath is None, Tags will do it's normal search and startdir is set
        to os.getcwd(). Otherwise tagpath is passed to Tags to raise the
        error. FIXME: fix comment
	'''
	body = []
	
	# If a tagfile is None, Tags will search for one.
	try:
		ctags = exctags.Tags(tagfile = tagfile, startdir = startdir)
	except RuntimeError, error:
		body.extend(['<h1><center>', str(error), '</center></h1>'])
		return done(body), -1
	
	body.extend(['<div class="smaller right">', str(ctags.tagfile), '</div>'])
	
	# Try an exact match first.
	lookup_type = 'exact match'
	matches = ctags.exact(name)
	if not matches:
		# Try partial if nothing was found
		lookup_type = 'partial match'
		matches = ctags.partial(name)
	
	body.extend(['<center><h3>',
		'<span id="tag">%s</span> &nbsp; &nbsp; &nbsp; %s' % (name, lookup_type), 
		'</h3></center>'])
	if not matches:
		body.append('<h3>No matching tags found</h3>')
	else:
		body.append('<center class="smaller">')
		body.append('<a href="javascript:void(0)" onclick="showAll();">Show All</a>')
		body.append(' &nbsp;&nbsp;&nbsp; ')
		body.append('<a href="javascript:void(0)" onclick="hideAll();">Hide All</a>')
		body.append('</center>')
		body.append('<ul>')
		for i in matches:
			tagcode, tagline = ctags.code(i, buffer = 10)
			body.append('<li>')
			body.append('''
					<a class="show" href="javascript:void(0)" 
						onclick="var e = document.getElementById('%d');
						if (e.style.display == 'block') {
							e.style.display = 'none';
							this.innerHTML = 'show';
						} else {
							e.style.display = 'block';
							this.innerHTML = 'hide';
						}
						">show</a>
					''' % (matches.index(i)))
			f = os.path.abspath(os.path.join(os.path.dirname(ctags.tagfile), i['file']))
			tmp = cgi.escape('file://%s&line=%d' % (f, tagline))
			tagurl = 'txmt://open?url=%s' % tmp
			body.append('<a href=%s>%s:%d</a>' % (tagurl, i['file'], tagline))
			tagkind = exctags.tagKinds.get(i['kind'], i['kind'])
			body.append('<div class="smaller">kind - ')
			body.append(tagkind)
			body.append('</div>')
			body.append('<pre class="code" id="%d">' % matches.index(i))
			body.append(hilight(cgi.escape(tagcode), i['name']))
			body.append('</pre>')
			body.append('</li>')
		body.append('</ul>')
	return done(body), 0

if __name__ == '__main__':
	print lookup()[0]
