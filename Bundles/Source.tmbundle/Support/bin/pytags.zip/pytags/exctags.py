"""
Copyright (c) 2006, Matthew Gilbert <gilbert AT voxmea DOT net>
This source code is released into the public domain.
"""

import os
import os.path as path
import re
import pytaglib

tagKinds = {
	"c": "class name",
	"d": "define (from #define XXX)",
	"e": "enumerator",
	"f": "function or method name",
	"F": "file name",
	"g": "enumeration name",
	"m": "member (of structure or class data)",
	"p": "function prototype",
	"s": "structure name",
	"t": "typedef",
	"u": "union name",
	"v": "variable",
}

class Tags:
	
	def __init__(self, tagfile = None, limit = '/', tagsname = 'tags', startdir = None):
		""" tagfile must be an actual file, it's passed to the readtags library. """
		if tagfile == None:
			def tagpath(curdir): return path.join(curdir, tagsname)
			# walk to limit directory starting from startdir to find tagfile
			curdir = os.getcwd()
			if startdir != None:
			    curdir = startdir
			if path.exists(tagpath(curdir)):
				tagfile = tagpath(curdir)
			else:
				while curdir != limit:
					curdir = path.abspath(path.join(curdir, path.pardir))
					if path.exists(tagpath(curdir)):
						tagfile = tagpath(curdir)
						break

		if tagfile == None:
			raise RuntimeError, 'tags file not found'
		if not path.exists(tagfile) or not path.isfile(tagfile):
			raise RuntimeError, 'tags file must exist'
		
		self.tagfile = tagfile
		self.pytobj = pytaglib.open(tagfile)
		
	def exact(self, name):
		return pytaglib.exact(self.pytobj, name)
		
	def partial(self, name):
		return pytaglib.partial(self.pytobj, name)
		
	def all(self):
		return pytaglib.all(self.pytobj)
		
	def _line(self, tag, srcfile):
		if tag['line'] != 0:
			return tag['line']
		
		match = tag['pattern'][2:-2]
		# Vim escapes the '/' character because it's an ex command delimter.
		# Otherwise the match strings look to be verbatim.
		match = match.replace('\/', '/')
		startpos = srcfile.tell()
		lines = srcfile.readlines()
		tagline = 0
		for i in lines:
			if re.search(re.escape(match), i):
				tagline = lines.index(i)
				break
		srcfile.seek(startpos, 0)
		return tagline
		
	def line(self, tag):
		return self._line(tag, self.getfile(tag))
		
	def code(self, tag, buffer = 20):
		srcfile = self.getfile(tag)
		line = self._line(tag, srcfile)
		if line == 0:
			return '"%s" not found in %s (maybe tags file out of sync)' % (tag['name'], srcfile.name), 0
		lines = srcfile.readlines()
		start = max(0, line - buffer)
		end = min(line + buffer, len(lines))
		return ''.join(lines[start : end]), line

	def getfile(self, tag):
		base = path.dirname(self.tagfile)
		return open(path.join(base, tag['file']))

	