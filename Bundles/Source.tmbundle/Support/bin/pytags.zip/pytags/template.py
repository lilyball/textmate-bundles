html = '''
<html>
<head>
	<title>ctags</title>
	<style type="text/css">
	html {
		background-color: #eee;
	}
	body {
		padding: 10px;
		border: 1px solid black;
		background-color: white;
	}
	ul {
		padding-left: 0px;
	}
	#content li {
		list-style: none;
		margin-top: 1ex;
		padding: 1ex;
	}
	.smaller {
		font-size: 80%;
	}
	.right {
		text-align: right;
	}
	span.hilight {
		font-weight: bold;
		color: darkred;
	}
	pre.code {
		display: none;
		background-color: #eee;
	}
	a.show {
		float: right;
	}
	#help {
		display: none;
		border: 1px dashed black;
		clear: both;
		padding: 10px;
		margin: 10px;
	}
	#showhelp {
		float: left;
		padding: 2px;
	}
	</style>
	<script type="text/javascript">
	function showAll() {
		var pre = document.getElementsByTagName('pre');
		var i;
		for (i = 0; i < pre.length; i++) {
			if (pre[i].className == 'code') {
				pre[i].style.display = 'block';
			}
		}
		var anchors = document.getElementsByTagName('a');
		for (i = 0; i < anchors.length; i++) {
			if (anchors[i].className == 'show') {
				anchors[i].innerHTML = 'hide';
			}
		}
	}

	function hideAll() {
		var pre = document.getElementsByTagName('pre');
		var i;
		for (i = 0; i < pre.length; i++) {
			if (pre[i].className == 'code') {
				pre[i].style.display = 'none';
			}
		}
		var anchors = document.getElementsByTagName('a');
		for (i = 0; i < anchors.length; i++) {
			if (anchors[i].className == 'show') {
				anchors[i].innerHTML = 'show';
			}
		}
	}
	
	function toggleHelp(href) {
		var elem = document.getElementById('help');
		if (elem.style.display != 'block') {
			elem.style.display = 'block';
			href.innerHTML = 'Hide help';
		}
		else {
			elem.style.display = 'none';
			href.innerHTML = 'Show help';
		}
	}
	</script>
</head>
<body>
<div class="smaller" id="showhelp">
	<a href="javascript:void(0)" onclick="toggleHelp(this);">Show help</a>
</div>
<div id="help">
	<h2>Exuberant Ctags Command</h2>
	<p>The <a href="http://ctags.sourceforge.net">Exuberant Ctags</a> command 
	performs a tag lookup using an existing tags file. To find the tags file,
	the command searches using the following order:
		<ol>
			<li>Searches for a project environment variable named TM_TAGS_FILE.
			This environment variable should contain the full path to the tags
			file.
			<li>Searches in the TM_PROJECT_DIRECTORY for a file named "tags."
			<li>Finally, it performs a search starting in the directory of the
			current file to the root of the file system for a file named "tags."
		</ol>
	</p>
</div>
<div id="content">
<!--REPLACE WITH BODY-->
</div>
</body>
</html>
'''